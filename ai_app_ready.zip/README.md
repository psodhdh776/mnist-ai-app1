# MNIST AI App

Простое приложение для распознавания цифр из MNIST.

## Как запустить

1. Установи зависимости:
```
pip install -r requirements.txt
```

2. Обучи модель (одна эпоха):
```
python backend/train.py
```

3. Запусти сервер:
```
uvicorn backend.serve:app --reload
```

4. Открой `frontend/index.html` в браузере.
